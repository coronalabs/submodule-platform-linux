#!/bin/bash

if [[ "$OSTYPE" == 'darwin'* ]]
then
	mkdir -p "${HOME}/Library/Application Support/Corona/Android Build/sdk/licenses"
	cp ../sdk/licenses/android-sdk-license "${HOME}/Library/Application Support/Corona/Android Build/sdk/licenses/"
	echo "sdk.dir=${HOME}/Library/Application Support/Corona/Android Build/sdk" > local.properties
else
	mkdir -p "${HOME}/.Solar2D/sdk/licenses"
	cp ../sdk/licenses/android-sdk-license "${HOME}/.Solar2D/sdk/licenses/"
	echo "sdk.dir=${HOME}/.Solar2D/sdk" > local.properties
fi
